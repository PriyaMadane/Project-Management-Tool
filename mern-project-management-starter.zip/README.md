
# MERN Project Management Starter

Features:
- User authentication (JWT)
- Projects, Task assignment and tracking
- Kanban board scaffold for workflows
- Team collaboration via comments
- Project analytics endpoints (task counts, velocity)
- Gantt chart scaffold for project timelines (frontend placeholder)
- Tech stack: MongoDB, Express, React, Node.js

Quick start:
1. Copy `backend/.env.example` to `backend/.env` and fill values.
2. From repo root start backend and frontend in separate terminals:

# Backend
cd backend
npm install
npm run dev

# Frontend
cd frontend
npm install
npm run dev

Seed sample data: node backend/seed.js
