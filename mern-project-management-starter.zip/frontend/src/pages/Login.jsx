
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Login(){
  const [email,setEmail] = useState('alice@example.com');
  const [password,setPassword] = useState('password');
  const nav = useNavigate();

  async function submit(e){
    e.preventDefault();
    const res = await axios.post((import.meta.env.VITE_API_URL||'http://localhost:5000') + '/api/auth/login', { email, password });
    localStorage.setItem('token', res.data.token);
    nav('/');
  }

  return (<div>
    <h2>Login (seeded user: alice@example.com / password)</h2>
    <form onSubmit={submit}><div><input value={email} onChange={e=>setEmail(e.target.value)} /></div>
    <div><input value={password} onChange={e=>setPassword(e.target.value)} type="password" /></div>
    <button>Login</button></form>
  </div>);
}
