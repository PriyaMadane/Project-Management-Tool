
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';

export default function Dashboard(){
  const [projects, setProjects] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [selProject, setSelProject] = useState(null);
  const nav = useNavigate();

  useEffect(()=>{ async function load(){ 
    const token = localStorage.getItem('token') || '';
    const p = await axios.get((import.meta.env.VITE_API_URL||'http://localhost:5000') + '/api/projects', { headers: { Authorization: 'Bearer ' + token } });
    setProjects(p.data);
    if(p.data[0]) { setSelProject(p.data[0]); const t = await axios.get((import.meta.env.VITE_API_URL||'http://localhost:5000') + '/api/tasks/project/' + p.data[0]._id, { headers: { Authorization: 'Bearer ' + token } }); setTasks(t.data); }
  } load(); },[]);

  if(projects.length === 0) return <div>No projects. <Link to="/login">Login</Link></div>;

  const workflow = selProject?.workflow || [{key:'todo',title:'To Do'},{key:'inprogress',title:'In Progress'},{key:'done',title:'Done'}];

  return (<div>
    <h2>Projects</h2>
    <div style={{ display:'flex', gap:10 }}>
      <div style={{ width: 200 }}>
        {projects.map(p=> <div key={p._id}><button onClick={()=>{ setSelProject(p); localStorage.setItem('projectId', p._id); window.location.reload(); }}>{p.title}</button></div>)}
      </div>
      <div style={{ flex: 1 }}>
        <h3>{selProject?.title} - Kanban</h3>
        <div style={{ display: 'flex', gap: 10 }}>
          {workflow.map(col=> (<div key={col.key} style={{ border:'1px solid #ddd', padding:10, width: '33%' }}>
            <h4>{col.title}</h4>
            {(tasks.filter(t=> t.status === col.key)).map(task=> (
              <div key={task._id} style={{ border:'1px solid #ccc', margin:6, padding:6 }} onClick={()=>nav('/project/' + selProject._id)}>
                <strong>{task.title}</strong><div>Assignee: {task.assignee?.name || 'Unassigned'}</div>
              </div>
            ))}
          </div>))}
        </div>
      </div>
    </div>
  </div>);
}
