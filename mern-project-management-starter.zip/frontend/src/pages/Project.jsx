
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

export default function Project(){
  const { id } = useParams();
  const [project, setProject] = useState(null);
  const [tasks, setTasks] = useState([]);

  useEffect(()=>{ async function load(){
    const token = localStorage.getItem('token') || '';
    const p = await axios.get((import.meta.env.VITE_API_URL||'http://localhost:5000') + '/api/projects/' + id, { headers: { Authorization: 'Bearer ' + token } });
    setProject(p.data);
    const t = await axios.get((import.meta.env.VITE_API_URL||'http://localhost:5000') + '/api/tasks/project/' + id, { headers: { Authorization: 'Bearer ' + token } });
    setTasks(t.data);
  } load(); },[id]);

  if(!project) return <div>Loading...</div>;

  return (<div>
    <h2>{project.title}</h2>
    <h3>Gantt chart (scaffold)</h3>
    <p>This is a placeholder Gantt view. Integrate a Gantt library (e.g., react-gantt-timeline) for production.</p>
    <div style={{ border:'1px solid #ddd', padding:10 }}>
      {tasks.map(t=> (<div key={t._id} style={{ margin:6 }}>
        <strong>{t.title}</strong> — {t.startDate ? new Date(t.startDate).toLocaleDateString() : 'start'} to {t.dueDate ? new Date(t.dueDate).toLocaleDateString() : 'due'}
      </div>))}
    </div>
  </div>);
}
