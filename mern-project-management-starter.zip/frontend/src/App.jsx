
import React from 'react';
import { Link, Routes, Route } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import Project from './pages/Project';
import Login from './pages/Login';
export default function App(){
  return (<div style={{ padding: 20 }}>
    <header style={{ display: 'flex', gap: 10 }}><Link to="/">Dashboard</Link></header>
    <main style={{ marginTop: 20 }}>
      <Routes>
        <Route path="/" element={<Dashboard/>} />
        <Route path="/project/:id" element={<Project/>} />
        <Route path="/login" element={<Login/>} />
      </Routes>
    </main>
  </div>);
}
