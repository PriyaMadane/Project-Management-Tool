
const express = require('express');
const router = express.Router();
const Task = require('../models/Task');
const auth = require('../middleware/auth');

router.post('/', auth, async (req,res)=>{
  try{
    const t = new Task(req.body);
    await t.save();
    res.json(t);
  }catch(e){ res.status(500).json({ message: e.message }); }
});

router.get('/project/:projectId', auth, async (req,res)=>{
  const items = await Task.find({ project: req.params.projectId }).populate('assignee', 'name email');
  res.json(items);
});

router.put('/:id', auth, async (req,res)=>{
  const t = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(t);
});

router.delete('/:id', auth, async (req,res)=>{
  await Task.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;
