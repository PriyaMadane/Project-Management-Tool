
const express = require('express');
const router = express.Router();
const Task = require('../models/Task');
const auth = require('../middleware/auth');

router.get('/project/:projectId/status-counts', auth, async (req,res)=>{
  const projectId = req.params.projectId;
  const agg = await Task.aggregate([
    { $match: { project: require('mongoose').Types.ObjectId(projectId) } },
    { $group: { _id: "$status", count: { $sum: 1 } } }
  ]);
  res.json(agg);
});

router.get('/project/:projectId/velocity', auth, async (req,res)=>{
  const projectId = req.params.projectId;
  const agg = await Task.aggregate([
    { $match: { project: require('mongoose').Types.ObjectId(projectId), completedAt: { $ne: null } } },
    { $group: { _id: { $week: "$completedAt" }, completed: { $sum: 1 } } },
    { $sort: { "_id": 1 } }
  ]);
  res.json(agg);
});

module.exports = router;
