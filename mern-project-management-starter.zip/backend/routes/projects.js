
const express = require('express');
const router = express.Router();
const Project = require('../models/Project');
const auth = require('../middleware/auth');

router.post('/', auth, async (req,res)=>{
  try{
    const p = new Project(req.body);
    await p.save();
    res.json(p);
  }catch(e){ res.status(500).json({ message: e.message }); }
});

router.get('/', auth, async (req,res)=>{
  const items = await Project.find().populate('members', 'name email');
  res.json(items);
});

router.get('/:id', auth, async (req,res)=>{
  const p = await Project.findById(req.params.id).populate('members', 'name email');
  res.json(p);
});

module.exports = router;
