
const express = require('express');
const router = express.Router();
const Comment = require('../models/Comment');
const auth = require('../middleware/auth');

router.post('/', auth, async (req,res)=>{
  try{
    const c = new Comment(req.body);
    await c.save();
    res.json(c);
  }catch(e){ res.status(500).json({ message: e.message }); }
});

router.get('/task/:taskId', auth, async (req,res)=>{
  const items = await Comment.find({ task: req.params.taskId }).populate('author', 'name email');
  res.json(items);
});

module.exports = router;
