
const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config();
const User = require('./models/User');
const Project = require('./models/Project');
const Task = require('./models/Task');
const bcrypt = require('bcryptjs');

const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/mern-pm';

async function seed(){
  await mongoose.connect(MONGO);
  await User.deleteMany({});
  await Project.deleteMany({});
  await Task.deleteMany({});
  const pw = await bcrypt.hash('password', 10);
  const u1 = await User.create({ name: 'Alice', email: 'alice@example.com', password: pw });
  const u2 = await User.create({ name: 'Bob', email: 'bob@example.com', password: pw });
  const proj = await Project.create({ title: 'Website Redesign', description: 'Revamp marketing site', members: [u1._id,u2._id], workflow: [{key:'todo',title:'To Do'},{key:'inprogress',title:'In Progress'},{key:'done',title:'Done'}] });
  await Task.create({ title: 'Design homepage', project: proj._id, assignee: u1._id, status: 'todo', priority: 'high' });
  await Task.create({ title: 'Implement header', project: proj._id, assignee: u2._id, status: 'inprogress' });
  console.log('Seeded');
  process.exit(0);
}

seed().catch(console.error);
