
const mongoose = require('mongoose');
const TaskSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project' },
  assignee: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  status: String,
  priority: { type: String, default: 'medium' },
  startDate: Date,
  dueDate: Date,
  timeEstimateHours: Number,
  completedAt: Date
}, { timestamps: true });
module.exports = mongoose.model('Task', TaskSchema);
