
const mongoose = require('mongoose');
const ProjectSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  members: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  workflow: [{ key: String, title: String }]
}, { timestamps: true });
module.exports = mongoose.model('Project', ProjectSchema);
